import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '20mb' }));

// Lazy initializer for GoogleGenAI instance
let aiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY environment variable is not set.');
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check route
app.get('/api/health', (req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status: 'ok',
    hasApiKey: hasKey,
    timestamp: new Date().toISOString(),
  });
});

// Non-streaming chat endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const {
      messages,
      systemInstruction,
      model = 'gemini-3.6-flash',
      enableSearch = false,
      temperature = 0.7,
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const ai = getGenAI();

    // Transform messages to Gemini format
    // Map history except last message
    const formattedContents = messages.map((msg: any) => {
      const parts: any[] = [];
      
      // Process attachments if any
      if (msg.attachments && Array.isArray(msg.attachments)) {
        for (const att of msg.attachments) {
          if (att.type === 'image' && att.data) {
            // Remove data URL prefix if present
            const base64Data = att.data.includes(',')
              ? att.data.split(',')[1]
              : att.data;
            parts.push({
              inlineData: {
                mimeType: att.mimeType || 'image/jpeg',
                data: base64Data,
              },
            });
          } else if (att.type === 'text' && att.data) {
            parts.push({ text: `[Attachment: ${att.name}]\n${att.data}` });
          }
        }
      }

      if (msg.content) {
        parts.push({ text: msg.content });
      }

      return {
        role: msg.role === 'model' ? 'model' : 'user',
        parts,
      };
    });

    const tools: any[] = [];
    if (enableSearch) {
      tools.push({ googleSearch: {} });
    }

    const config: any = {
      temperature,
    };

    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }

    if (tools.length > 0) {
      config.tools = tools;
    }

    const response = await ai.models.generateContent({
      model,
      contents: formattedContents,
      config,
    });

    const text = response.text || '';
    const groundingChunks =
      response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    res.json({
      text,
      groundingChunks,
    });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate response from Gemini API',
    });
  }
});

// Streaming chat endpoint using Server-Sent Events (SSE)
app.post('/api/chat/stream', async (req, res) => {
  try {
    const {
      messages,
      systemInstruction,
      model = 'gemini-3.6-flash',
      enableSearch = false,
      temperature = 0.7,
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const ai = getGenAI();

    const formattedContents = messages.map((msg: any) => {
      const parts: any[] = [];
      if (msg.attachments && Array.isArray(msg.attachments)) {
        for (const att of msg.attachments) {
          if (att.type === 'image' && att.data) {
            const base64Data = att.data.includes(',')
              ? att.data.split(',')[1]
              : att.data;
            parts.push({
              inlineData: {
                mimeType: att.mimeType || 'image/jpeg',
                data: base64Data,
              },
            });
          } else if (att.type === 'text' && att.data) {
            parts.push({ text: `[Attachment: ${att.name}]\n${att.data}` });
          }
        }
      }
      if (msg.content) {
        parts.push({ text: msg.content });
      }
      return {
        role: msg.role === 'model' ? 'model' : 'user',
        parts,
      };
    });

    const tools: any[] = [];
    if (enableSearch) {
      tools.push({ googleSearch: {} });
    }

    const config: any = {
      temperature,
    };
    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }
    if (tools.length > 0) {
      config.tools = tools;
    }

    const streamResponse = await ai.models.generateContentStream({
      model,
      contents: formattedContents,
      config,
    });

    let finalGroundingChunks: any[] = [];

    for await (const chunk of streamResponse) {
      const text = chunk.text || '';
      const groundingChunks =
        chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (groundingChunks && groundingChunks.length > 0) {
        finalGroundingChunks = groundingChunks;
      }

      res.write(
        `data: ${JSON.stringify({
          text,
          groundingChunks: finalGroundingChunks,
        })}\n\n`
      );
    }

    res.write(`data: [DONE]\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Error in /api/chat/stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message || 'Stream failed' });
    } else {
      res.write(
        `data: ${JSON.stringify({
          error: error.message || 'Stream error occurred',
        })}\n\n`
      );
      res.end();
    }
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
