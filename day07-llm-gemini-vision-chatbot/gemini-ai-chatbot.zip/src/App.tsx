import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, ChatSession, Persona, Attachment } from './types';
import { PERSONAS } from './data/personas';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MessageItem } from './components/MessageItem';
import { ChatInput } from './components/ChatInput';
import { PersonaSelector } from './components/PersonaSelector';
import { Bot, Sparkles, AlertCircle } from 'lucide-react';

const STORAGE_KEY = 'gemini_chatbot_sessions_v1';
const SETTINGS_KEY = 'gemini_chatbot_settings_v1';

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load sessions from storage:', e);
    }
    const defaultSession: ChatSession = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Conversation',
      createdAt: Date.now(),
      messages: [],
      systemInstruction: PERSONAS[0].systemInstruction,
      enableSearch: false,
      temperature: 0.7,
    };
    return [defaultSession];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(
    () => sessions[0]?.id || ''
  );

  const [currentPersonaId, setCurrentPersonaId] = useState<string>('assistant');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return (
      window.matchMedia &&
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [serverHealth, setServerHealth] = useState<{
    ok: boolean;
    hasKey: boolean;
  }>({ ok: true, hasKey: true });

  const abortControllerRef = useRef<AbortController | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Sync dark mode class on <html>
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Persist sessions
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save sessions:', e);
    }
  }, [sessions]);

  // Check server health on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setServerHealth({
          ok: data.status === 'ok',
          hasKey: Boolean(data.hasApiKey),
        });
      })
      .catch(() => {
        setServerHealth({ ok: false, hasKey: false });
      });
  }, []);

  // Active session
  const activeSession =
    sessions.find((s) => s.id === currentSessionId) || sessions[0];

  // Auto scroll to bottom
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages]);

  // Helper to update active session messages
  const updateActiveSession = (
    updater: (session: ChatSession) => ChatSession
  ) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === currentSessionId ? updater(s) : s))
    );
  };

  // Create new session
  const handleNewSession = () => {
    const persona = PERSONAS.find((p) => p.id === currentPersonaId) || PERSONAS[0];
    const newSession: ChatSession = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Conversation',
      createdAt: Date.now(),
      messages: [],
      systemInstruction: persona.systemInstruction,
      enableSearch: activeSession?.enableSearch ?? false,
      temperature: activeSession?.temperature ?? 0.7,
    };
    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  };

  // Delete session
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const newSession: ChatSession = {
          id: Math.random().toString(36).substr(2, 9),
          title: 'New Conversation',
          createdAt: Date.now(),
          messages: [],
          systemInstruction: PERSONAS[0].systemInstruction,
          enableSearch: false,
          temperature: 0.7,
        };
        setCurrentSessionId(newSession.id);
        return [newSession];
      }
      if (currentSessionId === id) {
        setCurrentSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  // Select persona
  const handleSelectPersona = (persona: Persona) => {
    setCurrentPersonaId(persona.id);
    updateActiveSession((s) => ({
      ...s,
      systemInstruction: persona.systemInstruction,
    }));
  };

  // Send message to server
  const handleSendMessage = async (text: string, attachments: Attachment[]) => {
    if (!text && attachments.length === 0) return;

    const userMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'user',
      content: text,
      timestamp: Date.now(),
      attachments: attachments.length > 0 ? attachments : undefined,
    };

    const botMessageId = Math.random().toString(36).substr(2, 9);
    const botMessagePlaceholder: ChatMessage = {
      id: botMessageId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
    };

    // Update active session with user and empty model message
    updateActiveSession((s) => {
      const isFirstMsg = s.messages.length === 0;
      const title = isFirstMsg
        ? text.slice(0, 30) || attachments[0]?.name || 'Chat'
        : s.title;
      return {
        ...s,
        title,
        messages: [...s.messages, userMessage, botMessagePlaceholder],
      };
    });

    setIsLoading(true);

    // Prepare abort controller
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const currentMessages = [...(activeSession?.messages || []), userMessage];

      // Try streaming endpoint
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          messages: currentMessages,
          systemInstruction: activeSession.systemInstruction,
          enableSearch: activeSession.enableSearch,
          temperature: activeSession.temperature,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server error ${response.status}`);
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let groundingChunks: any[] = [];

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunkText = decoder.decode(value, { stream: true });
        const lines = chunkText.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.replace(/^data:\s*/, '').trim();
            if (dataStr === '[DONE]') break;

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                accumulatedText += parsed.text;
              }
              if (parsed.groundingChunks && parsed.groundingChunks.length > 0) {
                groundingChunks = parsed.groundingChunks;
              }

              // Update state in real-time
              const currentText = accumulatedText;
              const currentChunks = groundingChunks;

              updateActiveSession((s) => ({
                ...s,
                messages: s.messages.map((m) =>
                  m.id === botMessageId
                    ? {
                        ...m,
                        content: currentText,
                        groundingChunks:
                          currentChunks.length > 0 ? currentChunks : undefined,
                      }
                    : m
                ),
              }));
            } catch (e) {
              // Non-JSON SSE line chunking
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream aborted by user');
      } else {
        console.error('Chat error:', err);
        updateActiveSession((s) => ({
          ...s,
          messages: s.messages.map((m) =>
            m.id === botMessageId
              ? {
                  ...m,
                  content:
                    err.message ||
                    'An error occurred while connecting to Gemini API.',
                  isError: true,
                }
              : m
          ),
        }));
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleStopStream = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    updateActiveSession((s) => ({
      ...s,
      messages: [],
    }));
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        currentPersonaId={currentPersonaId}
        onSelectPersona={handleSelectPersona}
        temperature={activeSession?.temperature ?? 0.7}
        onChangeTemperature={(val) =>
          updateActiveSession((s) => ({ ...s, temperature: val }))
        }
        enableSearch={activeSession?.enableSearch ?? false}
        onToggleSearch={() =>
          updateActiveSession((s) => ({ ...s, enableSearch: !s.enableSearch }))
        }
        systemInstruction={activeSession?.systemInstruction || ''}
        onChangeSystemInstruction={(text) =>
          updateActiveSession((s) => ({ ...s, systemInstruction: text }))
        }
      />

      {/* Main Chat Interface */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        <Header
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          onNewChat={handleNewSession}
          onClearChat={handleClearChat}
          currentTitle={activeSession?.title || 'Gemini AI Chat'}
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          onOpenSettings={() => setSidebarOpen(true)}
        />

        {/* Server status alert banner if missing API key or offline */}
        {!serverHealth.hasKey && (
          <div className="bg-amber-500/10 border-b border-amber-500/30 px-4 py-2 text-xs text-amber-700 dark:text-amber-300 flex items-center justify-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-500" />
            <span>
              API Key notice: Gemini API key is configured automatically via environment variables (`process.env.GEMINI_API_KEY`).
            </span>
          </div>
        )}

        {/* Scrollable Message List / Landing View */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeSession?.messages.length === 0 ? (
            <PersonaSelector
              currentPersonaId={currentPersonaId}
              onSelectPersona={handleSelectPersona}
              onSelectPrompt={(promptText) => handleSendMessage(promptText, [])}
            />
          ) : (
            <div className="max-w-4xl mx-auto space-y-4 pb-4">
              {activeSession?.messages.map((message) => (
                <MessageItem
                  key={message.id}
                  message={message}
                  onRetry={() => {
                    const lastUserMsg = [...activeSession.messages]
                      .reverse()
                      .find((m) => m.role === 'user');
                    if (lastUserMsg) {
                      handleSendMessage(
                        lastUserMsg.content,
                        lastUserMsg.attachments || []
                      );
                    }
                  }}
                />
              ))}
              <div ref={chatEndRef} />
            </div>
          )}
        </div>

        {/* Input Bar */}
        <ChatInput
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          onStopStream={handleStopStream}
          enableSearch={activeSession?.enableSearch ?? false}
          onToggleSearch={() =>
            updateActiveSession((s) => ({
              ...s,
              enableSearch: !s.enableSearch,
            }))
          }
        />
      </div>
    </div>
  );
}
