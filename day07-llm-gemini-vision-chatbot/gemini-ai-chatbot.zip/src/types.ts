export type Role = 'user' | 'model' | 'system';

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface Attachment {
  id: string;
  type: 'image' | 'text';
  name: string;
  data: string; // Base64 string for image or raw string for text
  mimeType: string;
}

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  groundingChunks?: GroundingChunk[];
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  messages: ChatMessage[];
  systemInstruction?: string;
  enableSearch?: boolean;
  temperature?: number;
}

export interface Persona {
  id: string;
  name: string;
  description: string;
  icon: string;
  systemInstruction: string;
  suggestedPrompts: string[];
}
