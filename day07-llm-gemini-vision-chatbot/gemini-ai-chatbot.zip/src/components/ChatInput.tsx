import React, { useState, useRef, useEffect } from 'react';
import { Send, Square, Paperclip, Image as ImageIcon, FileText, X, Globe } from 'lucide-react';
import { Attachment } from '../types';

interface ChatInputProps {
  onSendMessage: (text: string, attachments: Attachment[]) => void;
  isLoading: boolean;
  onStopStream?: () => void;
  enableSearch: boolean;
  onToggleSearch: () => void;
  disabled?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  onStopStream,
  enableSearch,
  onToggleSearch,
  disabled = false,
}) => {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(
        textareaRef.current.scrollHeight,
        180
      )}px`;
    }
  }, [text]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    if ((!text.trim() && attachments.length === 0) || isLoading || disabled) {
      return;
    }

    onSendMessage(text.trim(), attachments);
    setText('');
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();

      if (file.type.startsWith('image/')) {
        reader.onload = (event) => {
          const result = event.target?.result as string;
          if (result) {
            setAttachments((prev) => [
              ...prev,
              {
                id: Math.random().toString(36).substr(2, 9),
                type: 'image',
                name: file.name,
                data: result,
                mimeType: file.type,
              },
            ]);
          }
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = (event) => {
          const result = event.target?.result as string;
          if (result) {
            setAttachments((prev) => [
              ...prev,
              {
                id: Math.random().toString(36).substr(2, 9),
                type: 'text',
                name: file.name,
                data: result,
                mimeType: file.type || 'text/plain',
              },
            ]);
          }
        };
        reader.readAsText(file);
      }
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((att) => att.id !== id));
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-8 pb-6 pt-2">
      <div className="relative bg-[#050505] border border-slate-800 rounded-sm focus-within:border-amber-700/80 transition-colors shadow-xl">
        {/* Attachments preview list */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 p-3 border-b border-slate-900 bg-[#080808]">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="relative group flex items-center gap-2 p-1.5 px-3 rounded-sm bg-[#030303] border border-slate-800 text-xs font-mono text-slate-300"
              >
                {att.type === 'image' ? (
                  <ImageIcon className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                ) : (
                  <FileText className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                )}
                <span className="max-w-[140px] truncate">{att.name}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(att.id)}
                  className="p-0.5 hover:text-white text-slate-500 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Input Textarea */}
        <div className="px-4 pt-3">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Direct your inquiry..."
            rows={1}
            disabled={disabled}
            className="w-full bg-transparent text-slate-200 placeholder:text-slate-700 font-serif italic text-base sm:text-lg resize-none focus:outline-none min-h-[44px] max-h-[180px] py-1"
          />
        </div>

        {/* Controls Toolbar */}
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-slate-900 bg-[#030303]">
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              multiple
              accept="image/*,.txt,.js,.ts,.tsx,.json,.py,.html,.css,.md"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-1.5 px-2.5 rounded-sm border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-[11px] font-mono uppercase tracking-widest flex items-center gap-1.5 transition-colors"
              title="Attach media or context files"
            >
              <Paperclip className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Attach</span>
            </button>

            <button
              type="button"
              onClick={onToggleSearch}
              className={`p-1.5 px-2.5 rounded-sm border text-[11px] font-mono uppercase tracking-widest flex items-center gap-1.5 transition-colors ${
                enableSearch
                  ? 'border-amber-700/80 text-amber-500 bg-amber-950/20'
                  : 'border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700'
              }`}
              title="Toggle Google Search Grounding for live web analysis"
            >
              <Globe className={`w-3.5 h-3.5 ${enableSearch ? 'text-amber-500 animate-pulse' : ''}`} />
              <span className="hidden sm:inline">Search Grounding</span>
              {enableSearch && <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {isLoading ? (
              <button
                type="button"
                onClick={onStopStream}
                className="p-1.5 px-3 rounded-sm border border-amber-800/80 bg-amber-950/30 text-amber-400 hover:bg-amber-900/40 text-[11px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1.5"
                title="Halt response stream"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Halt</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={(!text.trim() && attachments.length === 0) || disabled}
                className={`py-1.5 px-4 rounded-sm font-mono text-[11px] uppercase tracking-widest transition-all flex items-center gap-1.5 ${
                  (!text.trim() && attachments.length === 0) || disabled
                    ? 'border border-slate-900 text-slate-700 bg-transparent cursor-not-allowed'
                    : 'bg-slate-100 hover:bg-white text-slate-950 font-bold active:scale-98 shadow-sm'
                }`}
              >
                <span>Send</span>
                <Send className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>
      <p className="mt-3 text-[9px] font-mono text-center text-slate-700 uppercase tracking-[0.4em]">
        Advanced LLM Orchestration • Gemini 3.6 Flash
      </p>
    </div>
  );
};
