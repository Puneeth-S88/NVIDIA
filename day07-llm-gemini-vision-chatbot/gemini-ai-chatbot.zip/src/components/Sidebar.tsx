import React from 'react';
import { ChatSession, Persona } from '../types';
import { PERSONAS } from '../data/personas';
import { Plus, Trash2, X, Sliders, Globe, ShieldCheck } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  currentPersonaId: string;
  onSelectPersona: (persona: Persona) => void;
  temperature: number;
  onChangeTemperature: (val: number) => void;
  enableSearch: boolean;
  onToggleSearch: () => void;
  systemInstruction: string;
  onChangeSystemInstruction: (text: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  currentPersonaId,
  onSelectPersona,
  temperature,
  onChangeTemperature,
  enableSearch,
  onToggleSearch,
  systemInstruction,
  onChangeSystemInstruction,
}) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Overlay for mobile */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 lg:hidden"
        onClick={onClose}
      />

      <aside className="fixed lg:static top-0 left-0 bottom-0 z-40 w-72 bg-[#050505] text-slate-300 flex flex-col border-r border-slate-800 shadow-2xl lg:shadow-none transition-all">
        {/* Sidebar Header */}
        <div className="p-6 pb-4 flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="text-2xl font-serif italic text-white tracking-tight">Nexus AI</h1>
            <span className="text-[9px] uppercase tracking-[0.3em] text-amber-600/90 font-mono mt-1">
              Gemini 3.6 Flash Engine
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-sm text-slate-500 hover:text-white hover:bg-slate-900 transition-colors lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Discussion Button */}
        <div className="px-6 mb-6">
          <button
            onClick={() => {
              onNewSession();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full py-2.5 px-4 rounded-sm border border-slate-700 text-xs uppercase tracking-widest text-slate-200 hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2 font-medium"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Discussion</span>
          </button>
        </div>

        {/* Navigation Sections */}
        <div className="flex-1 overflow-y-auto px-6 space-y-6">
          {/* Recent Sessions */}
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-3 font-semibold">
              Recent Sessions
            </p>
            {sessions.length === 0 ? (
              <p className="text-xs text-slate-600 italic">No recorded sessions</p>
            ) : (
              <ul className="space-y-2.5 text-xs">
                {sessions.map((session) => {
                  const isActive = session.id === currentSessionId;
                  return (
                    <li
                      key={session.id}
                      onClick={() => {
                        onSelectSession(session.id);
                        if (window.innerWidth < 1024) onClose();
                      }}
                      className={`group flex items-center justify-between cursor-pointer py-1 text-xs transition-colors ${
                        isActive ? 'text-slate-100 font-medium' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 pr-2">
                        <span
                          className={`${
                            isActive
                              ? 'w-1.5 h-1.5 bg-amber-600 rounded-full shrink-0'
                              : 'w-1 h-1 bg-slate-600 rounded-full shrink-0'
                          }`}
                        />
                        <span className="truncate">{session.title || 'Untitled Session'}</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteSession(session.id);
                        }}
                        className="text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-0.5"
                        title="Delete Session"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          {/* AI Personas */}
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-3 font-semibold">
              Agent Archetype
            </p>
            <div className="space-y-1">
              {PERSONAS.map((p) => {
                const isSelected = p.id === currentPersonaId;
                return (
                  <button
                    key={p.id}
                    onClick={() => onSelectPersona(p)}
                    className={`w-full text-left px-3 py-1.5 rounded-sm text-xs flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-slate-900 border-l-2 border-amber-600 text-amber-400 font-medium'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="truncate">{p.name}</span>
                    {isSelected && <span className="text-[10px] uppercase font-mono text-amber-600">Active</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Parameter Tuning */}
          <div className="pt-4 border-t border-slate-900 space-y-4">
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-semibold flex items-center gap-1.5">
              <Sliders className="w-3 h-3 text-amber-600" />
              <span>Hyperparameters</span>
            </p>

            {/* Temperature Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>CREATIVITY</span>
                <span className="text-amber-500">{temperature}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={temperature}
                onChange={(e) => onChangeTemperature(parseFloat(e.target.value))}
                className="w-full accent-amber-600 h-1 bg-slate-800 rounded-sm cursor-pointer"
              />
            </div>

            {/* Search Grounding Switch */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Globe className="w-3.5 h-3.5 text-amber-600" />
                <span>Search Grounding</span>
              </div>
              <button
                type="button"
                onClick={onToggleSearch}
                className={`w-8 h-4 rounded-full transition-colors relative ${
                  enableSearch ? 'bg-amber-700' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${
                    enableSearch ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* System Instruction */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-slate-500 font-mono">
                System Protocol
              </label>
              <textarea
                value={systemInstruction}
                onChange={(e) => onChangeSystemInstruction(e.target.value)}
                rows={3}
                placeholder="Direct systemic constraints..."
                className="w-full p-2 bg-[#0a0a0a] border border-slate-800 rounded-sm text-xs text-slate-300 placeholder:text-slate-700 focus:outline-none focus:border-amber-700 resize-none font-mono"
              />
            </div>
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="mt-auto p-6 border-t border-slate-900 bg-[#030303]">
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="text-[10px] uppercase tracking-widest text-emerald-500 font-medium">
              System Active
            </span>
          </div>
          <p className="text-[10px] font-mono text-slate-600 truncate">
            KEY: SERVER-SIDE API PROXY
          </p>
        </div>
      </aside>
    </>
  );
};
