import React, { useState } from 'react';
import Markdown from 'react-markdown';
import { Check, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<string | null>(null);

  const handleCopyCode = (codeText: string, id: string) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCodeIndex(id);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  return (
    <div className="prose prose-invert max-w-none text-slate-300 text-sm md:text-base leading-relaxed space-y-3 font-sans">
      <Markdown
        components={{
          code({ node, inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || '');
            const codeString = String(children).replace(/\n$/, '');
            const codeId = `${Math.random().toString(36).substring(2, 9)}`;

            if (!inline) {
              return (
                <div className="relative group my-4 rounded-sm overflow-hidden border border-slate-800 bg-[#050505] text-slate-200 font-mono text-xs md:text-sm">
                  <div className="flex items-center justify-between px-4 py-2 bg-[#0a0a0a] border-b border-slate-900 text-slate-500 font-mono text-[11px] uppercase tracking-wider">
                    <span className="text-amber-600 font-medium">{match ? match[1] : 'code'}</span>
                    <button
                      onClick={() => handleCopyCode(codeString, codeId)}
                      className="inline-flex items-center gap-1.5 hover:text-slate-200 transition-colors py-0.5 px-2 rounded-sm bg-slate-900 border border-slate-800"
                      title="Copy code"
                    >
                      {copiedCodeIndex === codeId ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400 text-[10px] tracking-widest">COPIED</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-slate-400" />
                          <span className="text-[10px] tracking-widest">COPY</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto text-slate-300 leading-relaxed font-mono">
                    <code className={className} {...props}>
                      {children}
                    </code>
                  </pre>
                </div>
              );
            }
            return (
              <code
                className="bg-slate-900 text-amber-500 px-1.5 py-0.5 rounded-sm text-xs font-mono border border-slate-800"
                {...props}
              >
                {children}
              </code>
            );
          },
          ul({ children }) {
            return (
              <ul className="list-none pl-4 border-l border-amber-900/40 space-y-2 my-3 italic text-slate-300">
                {children}
              </ul>
            );
          },
          ol({ children }) {
            return (
              <ol className="list-decimal list-inside space-y-2 my-3 pl-2 text-slate-300">
                {children}
              </ol>
            );
          },
          p({ children }) {
            return <p className="mb-3 last:mb-0 leading-relaxed">{children}</p>;
          },
          h1({ children }) {
            return (
              <h1 className="font-serif text-xl md:text-2xl font-normal mt-5 mb-3 text-white tracking-tight border-b border-slate-900 pb-2">
                {children}
              </h1>
            );
          },
          h2({ children }) {
            return (
              <h2 className="font-serif text-lg md:text-xl font-normal mt-4 mb-2 text-slate-100 tracking-tight">
                {children}
              </h2>
            );
          },
          h3({ children }) {
            return (
              <h3 className="font-serif text-base font-medium mt-3 mb-2 text-slate-200">
                {children}
              </h3>
            );
          },
          blockquote({ children }) {
            return (
              <blockquote className="border-l-2 border-amber-600/80 pl-4 italic font-serif text-slate-300 my-4 bg-slate-900/30 py-2 rounded-r-sm">
                {children}
              </blockquote>
            );
          },
          a({ href, children }) {
            return (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-500 hover:text-amber-400 underline underline-offset-4 decoration-amber-800 font-medium transition-colors"
              >
                {children}
              </a>
            );
          }
        }}
      >
        {content}
      </Markdown>
    </div>
  );
};
