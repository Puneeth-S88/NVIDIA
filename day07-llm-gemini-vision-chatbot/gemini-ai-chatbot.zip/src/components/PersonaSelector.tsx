import React from 'react';
import { PERSONAS } from '../data/personas';
import { Persona } from '../types';
import { Bot, Code, PenTool, BarChart3, GraduationCap, ArrowRight, Shield } from 'lucide-react';

interface PersonaSelectorProps {
  currentPersonaId: string;
  onSelectPersona: (persona: Persona) => void;
  onSelectPrompt: (prompt: string) => void;
}

const getIcon = (iconName: string) => {
  switch (iconName) {
    case 'Code':
      return <Code className="w-4 h-4 text-amber-600" />;
    case 'PenTool':
      return <PenTool className="w-4 h-4 text-amber-600" />;
    case 'BarChart3':
      return <BarChart3 className="w-4 h-4 text-amber-600" />;
    case 'GraduationCap':
      return <GraduationCap className="w-4 h-4 text-amber-600" />;
    default:
      return <Bot className="w-4 h-4 text-amber-600" />;
  }
};

export const PersonaSelector: React.FC<PersonaSelectorProps> = ({
  currentPersonaId,
  onSelectPersona,
  onSelectPrompt,
}) => {
  const currentPersona =
    PERSONAS.find((p) => p.id === currentPersonaId) || PERSONAS[0];

  return (
    <div className="w-full max-w-4xl mx-auto py-10 px-4 space-y-10">
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#050505] border border-slate-800 text-[10px] uppercase font-mono tracking-[0.2em] text-amber-600">
          <Shield className="w-3 h-3" />
          <span>Gemini 3.6 Flash Active</span>
        </div>
        <h1 className="text-3xl md:text-5xl font-serif italic text-white tracking-tight">
          Commence Inquiry
        </h1>
        <p className="text-xs uppercase tracking-[0.25em] text-slate-500 font-mono max-w-md mx-auto">
          Select an agent archetype or initiate with a directive below
        </p>
      </div>

      {/* Persona Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {PERSONAS.map((persona) => {
          const isSelected = persona.id === currentPersonaId;
          return (
            <button
              key={persona.id}
              onClick={() => onSelectPersona(persona)}
              className={`flex flex-col items-center text-center p-4 rounded-sm border transition-all group ${
                isSelected
                  ? 'bg-slate-900 border-amber-600 text-amber-400'
                  : 'bg-[#050505] border-slate-800/80 hover:border-slate-700 text-slate-400'
              }`}
            >
              <div className="p-2 rounded-sm bg-[#0a0a0a] border border-slate-800 mb-2.5">
                {getIcon(persona.icon)}
              </div>
              <h3 className="text-xs font-mono uppercase tracking-wider font-semibold truncate w-full">
                {persona.name}
              </h3>
              <p className="text-[10px] text-slate-500 line-clamp-2 mt-1 font-sans">
                {persona.description}
              </p>
            </button>
          );
        })}
      </div>

      {/* Suggested Prompts for Current Persona */}
      <div className="space-y-4 pt-4 border-t border-slate-900">
        <h4 className="text-[10px] uppercase tracking-[0.25em] text-slate-500 font-mono text-center font-semibold">
          Suggested Directives — {currentPersona.name}
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {currentPersona.suggestedPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => onSelectPrompt(prompt)}
              className="group flex items-center justify-between p-4 rounded-sm bg-[#050505] border border-slate-800/80 hover:border-amber-700/60 transition-all text-left"
            >
              <span className="text-xs md:text-sm text-slate-300 font-serif italic group-hover:text-amber-400 transition-colors">
                "{prompt}"
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-500 group-hover:translate-x-1 transition-all shrink-0 ml-3" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
