import React, { useState } from 'react';
import { ChatMessage } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Copy, Check, Globe, AlertTriangle, FileText, Sparkles } from 'lucide-react';

interface MessageItemProps {
  message: ChatMessage;
  onRetry?: () => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({ message, onRetry }) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      className={`group flex flex-col my-4 transition-all ${
        isUser
          ? 'items-end max-w-2xl ml-auto'
          : 'items-start max-w-3xl mr-auto w-full'
      }`}
    >
      {/* Content box */}
      <div
        className={`w-full p-5 sm:p-6 rounded-sm transition-colors ${
          isUser
            ? 'bg-slate-900/60 border border-slate-800 text-slate-200 shadow-sm'
            : message.isError
            ? 'bg-red-950/20 border border-red-900/40 text-red-300'
            : 'bg-transparent text-slate-300'
        }`}
      >
        {/* Attachments preview */}
        {message.attachments && message.attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3 pb-2 border-b border-slate-800/60">
            {message.attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-2 p-1.5 px-3 rounded-sm bg-[#050505] border border-slate-800 text-xs text-slate-300 max-w-xs"
              >
                {att.type === 'image' ? (
                  <>
                    <img
                      src={att.data}
                      alt={att.name}
                      className="w-8 h-8 object-cover rounded-sm border border-slate-700"
                    />
                    <div className="truncate">
                      <p className="font-medium truncate text-xs">{att.name}</p>
                      <p className="text-[9px] font-mono text-amber-600">IMAGE</p>
                    </div>
                  </>
                ) : (
                  <>
                    <FileText className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="truncate font-mono text-xs">{att.name}</span>
                  </>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Text body */}
        {message.isError ? (
          <div className="flex items-start gap-2.5 text-red-400 text-sm font-sans">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
            <div>
              <p className="font-medium">{message.content}</p>
              {onRetry && (
                <button
                  onClick={onRetry}
                  className="mt-2 text-xs font-mono uppercase tracking-widest text-red-400 hover:text-red-300 underline cursor-pointer"
                >
                  [ Retry Protocol ]
                </button>
              )}
            </div>
          </div>
        ) : (
          <MarkdownRenderer content={message.content} />
        )}

        {/* Grounding Web Sources */}
        {message.groundingChunks && message.groundingChunks.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-900 text-xs space-y-2">
            <div className="flex items-center gap-1.5 text-slate-500 font-mono text-[10px] uppercase tracking-widest">
              <Globe className="w-3 h-3 text-amber-600" />
              <span>Verified Search Grounding</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {message.groundingChunks.map((chunk, idx) => {
                if (!chunk.web?.uri) return null;
                return (
                  <a
                    key={idx}
                    href={chunk.web.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 py-1 px-3 rounded-sm bg-[#050505] text-amber-500/90 border border-slate-800 hover:border-amber-700/60 transition-colors text-[11px] font-mono"
                  >
                    <span className="truncate max-w-[200px]">
                      {chunk.web.title || chunk.web.uri}
                    </span>
                  </a>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Footer bar for timestamp & copy */}
      <div className="flex items-center justify-between w-full mt-2 px-1">
        <span
          className={`text-[10px] font-mono uppercase tracking-widest ${
            isUser ? 'text-slate-600' : 'text-amber-700/90'
          }`}
        >
          {isUser ? `Investigator • ${formattedTime}` : `Nexus AI • Completed ${formattedTime}`}
        </span>

        <button
          onClick={handleCopy}
          className="text-[10px] font-mono uppercase tracking-widest text-slate-600 hover:text-slate-300 transition-colors flex items-center gap-1"
          title="Copy message"
        >
          {copied ? (
            <span className="text-emerald-500">Copied</span>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
