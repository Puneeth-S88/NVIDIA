import React from 'react';
import { Menu, Plus, SlidersHorizontal, Trash2, Shield, Activity } from 'lucide-react';

interface HeaderProps {
  onToggleSidebar: () => void;
  onNewChat: () => void;
  onClearChat: () => void;
  currentTitle: string;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  onNewChat,
  onClearChat,
  currentTitle,
  onOpenSettings,
}) => {
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between h-16 px-6 sm:px-8 bg-[#0A0A0A]/90 backdrop-blur-md border-b border-slate-900">
      <div className="flex items-center gap-4">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-sm text-slate-400 hover:text-white hover:bg-slate-900/80 transition-colors border border-transparent hover:border-slate-800"
          title="Toggle Sidebar"
        >
          <Menu className="w-4 h-4" />
        </button>

        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase tracking-[0.25em] text-slate-500 font-semibold">
              Agent Protocol <span className="text-amber-600 font-mono">v3.6</span>
            </span>
          </div>
          <h2 className="font-serif italic text-sm md:text-base text-slate-200 truncate max-w-[200px] md:max-w-md tracking-tight">
            {currentTitle || 'Current Investigation'}
          </h2>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full border border-slate-900 bg-[#050505] text-[10px] font-mono text-slate-500">
          <Activity className="w-3 h-3 text-amber-600 animate-pulse" />
          <span className="tracking-widest">3.6 FLASH</span>
        </div>

        <button
          onClick={onNewChat}
          className="hidden sm:flex items-center gap-2 py-1.5 px-3 rounded-sm border border-slate-800 hover:border-amber-700/60 text-slate-300 hover:text-amber-400 text-[11px] uppercase tracking-widest transition-all bg-[#050505]"
          title="New Discussion"
        >
          <Plus className="w-3.5 h-3.5 text-amber-600" />
          <span>New Discussion</span>
        </button>

        <button
          onClick={onOpenSettings}
          className="p-2 rounded-sm text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-slate-800/60 transition-colors"
          title="Protocol Settings"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        <button
          onClick={onClearChat}
          className="p-2 rounded-sm text-slate-500 hover:text-red-400 hover:bg-slate-900 border border-slate-800/60 transition-colors"
          title="Clear session output"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
